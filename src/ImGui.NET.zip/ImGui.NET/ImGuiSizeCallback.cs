﻿namespace ImGuiNET
{
    public unsafe delegate void ImGuiSizeCallback(ImGuiSizeCallbackData* data);
}
