﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ImGuiNET
{

    public unsafe delegate void ImGuiErrorLogCallback(ImGuiErrorLogCallbackData* data);
}
