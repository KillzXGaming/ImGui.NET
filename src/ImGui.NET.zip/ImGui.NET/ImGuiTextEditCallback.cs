﻿namespace ImGuiNET
{
    public unsafe delegate int ImGuiInputTextCallback(ImGuiInputTextCallbackData* data);
}
