namespace ImGuiNET
{
    [System.Flags]
    public enum ImGuiTextFlags
    {
        None = 0,
        NoWidthForLargeClippedText = 1 << 0,
    }
}
