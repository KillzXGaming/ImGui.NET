namespace ImGuiNET
{
    public enum ImGuiInputReadMode
    {
        _Down = 0,
        _Pressed = 1,
        _Released = 2,
        _Repeat = 3,
        _RepeatSlow = 4,
        _RepeatFast = 5,
    }
}
