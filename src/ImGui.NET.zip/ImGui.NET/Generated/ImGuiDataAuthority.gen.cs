namespace ImGuiNET
{
    public enum ImGuiDataAuthority
    {
        Auto = 0,
        DockNode = 1,
        Window = 2,
    }
}
