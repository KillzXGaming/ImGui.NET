namespace ImGuiNET
{
    public enum ImGuiNavLayer
    {
        _Main = 0,
        _Menu = 1,
        _COUNT = 2,
    }
}
