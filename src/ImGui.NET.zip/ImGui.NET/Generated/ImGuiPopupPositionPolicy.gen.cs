namespace ImGuiNET
{
    public enum ImGuiPopupPositionPolicy
    {
        _Default = 0,
        _ComboBox = 1,
        _Tooltip = 2,
    }
}
