namespace ImGuiNET
{
    public enum ImGuiLogType
    {
        _None = 0,
        _TTY = 1,
        _File = 2,
        _Buffer = 3,
        _Clipboard = 4,
    }
}
