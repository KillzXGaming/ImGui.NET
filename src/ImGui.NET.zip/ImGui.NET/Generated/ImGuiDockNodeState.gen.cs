namespace ImGuiNET
{
    public enum ImGuiDockNodeState
    {
        _Unknown = 0,
        _HostWindowHiddenBecauseSingleWindow = 1,
        _HostWindowHiddenBecauseWindowsAreResizing = 2,
        _HostWindowVisible = 3,
    }
}
