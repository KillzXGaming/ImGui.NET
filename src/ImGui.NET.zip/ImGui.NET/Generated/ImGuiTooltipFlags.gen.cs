namespace ImGuiNET
{
    [System.Flags]
    public enum ImGuiTooltipFlags
    {
        None = 0,
        OverridePreviousTooltip = 1 << 0,
    }
}
