namespace ImGuiNET
{
    [System.Flags]
    public enum ImGuiTableRowFlags
    {
        None = 0,
        Headers = 1 << 0,
    }
}
