namespace ImGuiNET
{
    public enum ImGuiLayoutType
    {
        Horizontal = 0,
        Vertical = 1,
    }
}
