namespace ImGuiNET
{
    public enum ImGuiInputSource
    {
        _None = 0,
        _Mouse = 1,
        _Nav = 2,
        _NavKeyboard = 3,
        _NavGamepad = 4,
        _COUNT = 5,
    }
}
