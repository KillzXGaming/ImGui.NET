namespace ImGuiNET
{
    public enum ImGuiTableBgTarget
    {
        None = 0,
        RowBg0 = 1,
        RowBg1 = 2,
        CellBg = 3,
    }
}
