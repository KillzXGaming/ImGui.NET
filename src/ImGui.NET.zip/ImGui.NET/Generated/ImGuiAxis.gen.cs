namespace ImGuiNET
{
    public enum ImGuiAxis
    {
        _None = -1,
        _X = 0,
        _Y = 1,
    }
}
