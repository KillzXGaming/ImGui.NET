namespace ImGuiNET
{
    public enum ImGuiPlotType
    {
        _Lines = 0,
        _Histogram = 1,
    }
}
