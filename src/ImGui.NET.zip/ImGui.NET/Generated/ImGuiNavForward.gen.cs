namespace ImGuiNET
{
    public enum ImGuiNavForward
    {
        _None = 0,
        _ForwardQueued = 1,
        _ForwardActive = 2,
    }
}
