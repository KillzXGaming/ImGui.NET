namespace ImGuiNET
{
    public enum ImGuiWindowDockStyleCol
    {
        _Text = 0,
        _Tab = 1,
        _TabHovered = 2,
        _TabActive = 3,
        _TabUnfocused = 4,
        _TabUnfocusedActive = 5,
        _COUNT = 6,
    }
}
